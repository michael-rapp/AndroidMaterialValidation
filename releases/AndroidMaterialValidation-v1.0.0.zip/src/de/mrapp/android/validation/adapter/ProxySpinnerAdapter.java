/*
 * AndroidMaterialValidation Copyright 2015 Michael Rapp
 *
 * This program is free software: you can redistribute it and/or modify 
 * it under the terms of the GNU Lesser General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, or 
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public 
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/>. 
 */
package de.mrapp.android.validation.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import static de.mrapp.android.validation.util.Condition.ensureNotNull;

/**
 * A spinner adapter, which acts as a proxy for an other adapter in order to
 * initially show a hint instead of the adapter's first item.
 * 
 * @author Michael Rapp
 * 
 * @since 1.0.0
 */
public class ProxySpinnerAdapter implements SpinnerAdapter, ListAdapter {

	/**
	 * The context, which is used by the adapter.
	 */
	private final Context context;

	/**
	 * The adapter, which contains the actual items.
	 */
	private final SpinnerAdapter adapter;

	/**
	 * The resource id if the layout, which should be used to display the hint.
	 */
	private final int hintViewId;

	/**
	 * The hint, which is displayed initially.
	 */
	private final CharSequence hint;

	/**
	 * The color of the hint, which is displayed initially.
	 */
	private final ColorStateList hintColor;

	/**
	 * Inflates and returns the view, which is used to display the hint.
	 * 
	 * @param parent
	 *            The parent view of the view, which should be inflated, as an
	 *            instance of the class {@link ViewGroup}
	 * @return The view, which has been inflated, as an instance of the class
	 *         {@link View}
	 */
	private View inflateHintView(final ViewGroup parent) {
		TextView view = (TextView) LayoutInflater.from(context).inflate(
				hintViewId, parent, false);
		view.setText(hint);

		if (hintColor != null) {
			view.setTextColor(hintColor);
		}

		return view;
	}

	/**
	 * Creates a new spinner adapter, which acts as a proxy for an other adapter
	 * in order to initially show a hint instead of the adapter's first item.
	 * 
	 * @param context
	 *            The context, which should be used by the adapter, as an
	 *            instance of the class {@link Context}. The context may not be
	 *            null
	 * @param adapter
	 *            The adapter, which contains the actual items, as an instance
	 *            of the type {@link SpinnerAdapter}. The adapter may not be
	 *            null
	 * @param hintViewId
	 *            The resource id of the layout, which should be used to display
	 *            the hint, as an {@link Integer} value. The resource id must
	 *            corresponds to a valid layout resource
	 * @param hint
	 *            The hint, which should be displayed initially, as an instance
	 *            of the type {@link CharSequence} or null, if no hint should be
	 *            displayed
	 * @param hintColor
	 *            The color of the hint, which should be displayed initially, as
	 *            an instance of the class {@link ColorStateList} or null, if
	 *            the default color should be used
	 */
	public ProxySpinnerAdapter(final Context context,
			final SpinnerAdapter adapter, final int hintViewId,
			final CharSequence hint, final ColorStateList hintColor) {
		ensureNotNull(context, "The context may not be null");
		ensureNotNull(adapter, "The adapter may not be null");
		this.context = context;
		this.adapter = adapter;
		this.hintViewId = hintViewId;
		this.hint = hint;
		this.hintColor = hintColor;
	}

	/**
	 * Returns the adapter, which contains the actual items.
	 * 
	 * @return The adapter, which contains the actual items, as an instance of
	 *         the type {@link SpinnerAdapter}
	 */
	public final SpinnerAdapter getAdapter() {
		return adapter;
	}

	@Override
	public final View getView(final int position, final View convertView,
			final ViewGroup parent) {
		if (position == 0) {
			return inflateHintView(parent);
		}

		return adapter.getView(position - 1, null, parent);
	}

	@Override
	public final View getDropDownView(final int position,
			final View convertView, final ViewGroup parent) {
		if (position == 0) {
			return new View(context);
		}

		return adapter.getDropDownView(position - 1, null, parent);
	}

	@Override
	public final int getCount() {
		return adapter.getCount() == 0 ? 0 : adapter.getCount() + 1;
	}

	@Override
	public final Object getItem(final int position) {
		return position == 0 ? null : adapter.getItem(position - 1);
	}

	@Override
	public final int getItemViewType(final int position) {
		return 0;
	}

	@Override
	public final int getViewTypeCount() {
		return 1;
	}

	@Override
	public final long getItemId(final int position) {
		return position > 0 ? adapter.getItemId(position - 1) : -1;
	}

	@Override
	public final boolean hasStableIds() {
		return adapter.hasStableIds();
	}

	@Override
	public final boolean isEmpty() {
		return adapter.isEmpty();
	}

	@Override
	public final void registerDataSetObserver(final DataSetObserver observer) {
		adapter.registerDataSetObserver(observer);
	}

	@Override
	public final void unregisterDataSetObserver(final DataSetObserver observer) {
		adapter.unregisterDataSetObserver(observer);
	}

	@Override
	public final boolean areAllItemsEnabled() {
		return false;
	}

	@Override
	public final boolean isEnabled(final int position) {
		return position > 0;
	}

}